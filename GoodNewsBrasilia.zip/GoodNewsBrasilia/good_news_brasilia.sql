/* BD FEITO POR FILIPE MARREIRA
MATRICULA: 202210937 / PROJETO - Good News Brasilia*/

-- DELETAR BD SE ELE JÁ EXISTIR
DROP DATABASE IF EXISTS good_news_brasilia;

-- CRIANDO O BD
CREATE DATABASE good_news_brasilia;
USE good_news_brasilia;

-- CRIANDO AS TABELAS
CREATE TABLE noticias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(30) NOT NULL,
    subtitulo VARCHAR(30),
    conteudo TEXT NOT NULL,
    imagem VARCHAR(255),
    data_publicacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, -- CONTROLAR ATUALIZAÇÕES
    CONSTRAINT uc_noticia_titulo UNIQUE (titulo)
);

CREATE TABLE comentarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    noticia_id INT NOT NULL,
    comentario TEXT NOT NULL,
    data_comentario TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (noticia_id) REFERENCES noticias(id) ON DELETE CASCADE -- É DELETADO JUNTO COM A NOTICIA
);

CREATE TABLE login (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL,
    email VARCHAR(50) NOT NULL UNIQUE,
    senha VARCHAR(8) NOT NULL,
    cpf VARCHAR(14) NOT NULL UNIQUE
) ENGINE = InnoDB;

-- INDICE PARA CONSULTAS
CREATE INDEX idx_titulo ON noticias(titulo);
CREATE INDEX idx_noticia_id ON comentarios(noticia_id);
CREATE INDEX idx_data_publicacao ON noticias(data_publicacao);

-- CONSULTAR NOTICIAS INSERIDAS
SELECT id, titulo, subtitulo, conteudo, imagem, data_publicacao, data_atualizacao FROM noticias;

-- CONSULTAR COMENTÁRIOS
SELECT * FROM comentarios;

-- CONSULTAR COMENTÁRIOS
SELECT * FROM login;
SELECT * FROM noticias;

-- EXCLUIR NOTICIA
DELETE FROM noticias WHERE id = 1;

-- VERIFICA SE A NOTICIA FOI EXCLUIDA JUNTO COM COMENTARIOS
SELECT id, titulo, subtitulo, conteudo, imagem, data_publicacao, data_atualizacao FROM noticias;

-- EXCLUIR NOTICIA
SELECT * FROM comentarios WHERE noticia_id = 1;
