package com.goodnews.CadastroBean;

import com.goodnews.utils.UserAuthentication;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped
public class CadastroBean {

    private String nome;
    private String emailCadastro;
    private String senhaCadastro;
    private String cpf;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmailCadastro() {
        return emailCadastro;
    }

    public void setEmailCadastro(String emailCadastro) {
        this.emailCadastro = emailCadastro;
    }

    public String getSenhaCadastro() {
        return senhaCadastro;
    }

    public void setSenhaCadastro(String senhaCadastro) {
        this.senhaCadastro = senhaCadastro;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String cadastrar() {
        boolean isRegistered = UserAuthentication.registerUser(nome, emailCadastro, senhaCadastro, cpf);
        if (isRegistered) {
            
            return "login?faces-redirect=true"; 
        } else {
            
            return null;
        }
    }
}