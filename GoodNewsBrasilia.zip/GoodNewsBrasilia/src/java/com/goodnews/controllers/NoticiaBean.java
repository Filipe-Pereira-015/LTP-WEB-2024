package com.goodnews.controllers;

import com.goodnews.models.Comentario;
import com.goodnews.models.Noticia;
import com.goodnews.utils.DBConnection;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.Part;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@ManagedBean(name = "noticiaBean")
@ViewScoped
public class NoticiaBean {

    private List<Noticia> noticias;
    private Noticia novaNoticia;
    private Noticia noticiaSelecionada;
    private String novoComentario;
    private Part imagemArquivo;
    private int noticiaId;

    @PostConstruct
    public void init() {
        try {
            novaNoticia = new Noticia();
            noticiaSelecionada = new Noticia();
            carregarNoticias();

            
            String idParam = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("id");
            if (idParam != null && !idParam.isEmpty()) {
                noticiaId = Integer.parseInt(idParam);
                carregarNoticia();
            }
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro", "Erro na inicialização: " + e.getMessage()));
        }
    }

    
    public List<Noticia> getNoticias() {
        return noticias;
    }

    public Noticia getNovaNoticia() {
        return novaNoticia;
    }

    public void setNovaNoticia(Noticia novaNoticia) {
        this.novaNoticia = novaNoticia;
    }

    public Noticia getNoticiaSelecionada() {
        return noticiaSelecionada;
    }

    public void setNoticiaSelecionada(Noticia noticiaSelecionada) {
        this.noticiaSelecionada = noticiaSelecionada;
    }

    public String getNovoComentario() {
        return novoComentario;
    }

    public void setNovoComentario(String novoComentario) {
        this.novoComentario = novoComentario;
    }

    public Part getImagemArquivo() {
        return imagemArquivo;
    }

    public void setImagemArquivo(Part imagemArquivo) {
        this.imagemArquivo = imagemArquivo;
    }

    public int getNoticiaId() {
        return noticiaId;
    }

    public void setNoticiaId(int noticiaId) {
        this.noticiaId = noticiaId;
    }

    // Método para carregar todas as notícias
    private void carregarNoticias() {
        noticias = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM noticias ORDER BY data_publicacao DESC");
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Noticia noticia = new Noticia();
                noticia.setId(rs.getInt("id"));
                noticia.setTitulo(rs.getString("titulo"));
                noticia.setSubtitulo(rs.getString("subtitulo"));
                noticia.setConteudo(rs.getString("conteudo"));
                noticia.setImagem(rs.getString("imagem"));
                noticia.setDataPublicacao(rs.getTimestamp("data_publicacao"));
                carregarComentarios(noticia);
                noticias.add(noticia);
            }
        } catch (SQLException e) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro", "Erro ao carregar notícias." + e.getMessage()));
        }
    }

    // Método para carregar comentários
    private void carregarComentarios(Noticia noticia) {
        List<Comentario> comentarios = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM comentarios WHERE noticia_id = ? ORDER BY data_comentario DESC")) {
            stmt.setInt(1, noticia.getId());
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Comentario comentario = new Comentario();
                comentario.setId(rs.getLong("id"));
                comentario.setNoticiaId(rs.getInt("noticia_id"));
                comentario.setComentario(rs.getString("comentario"));
                comentario.setDataComentario(rs.getString("data_comentario"));
                comentarios.add(comentario);
            }
        } catch (SQLException e) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro", "Erro ao carregar comentários." + e.getMessage()));
        }
        noticia.setComentarios(comentarios);
    }

    // Carregar notícia por ID
    public void carregarNoticia() {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM noticias WHERE id = ?")) {
            stmt.setInt(1, noticiaId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                noticiaSelecionada.setId(rs.getInt("id"));
                noticiaSelecionada.setTitulo(rs.getString("titulo"));
                noticiaSelecionada.setSubtitulo(rs.getString("subtitulo"));
                noticiaSelecionada.setConteudo(rs.getString("conteudo"));
                noticiaSelecionada.setImagem(rs.getString("imagem"));
                noticiaSelecionada.setDataPublicacao(rs.getTimestamp("data_publicacao"));
                carregarComentarios(noticiaSelecionada);
            }
        } catch (SQLException e) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro", "Erro ao carregar a notícia." + e.getMessage()));
        }
    }

    public void excluirNoticia(int noticiaId) {
        try (Connection conn = DBConnection.getConnection()) {
            // Excluir comentários associados
            String deleteComentariosSql = "DELETE FROM comentarios WHERE noticia_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(deleteComentariosSql)) {
                stmt.setInt(1, noticiaId);
                stmt.executeUpdate();
            }

            // Excluir a notícia
            String deleteNoticiaSql = "DELETE FROM noticias WHERE id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(deleteNoticiaSql)) {
                stmt.setInt(1, noticiaId);
                stmt.executeUpdate();
            }

            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_INFO, "Sucesso", "Notícia excluída com sucesso."));

            carregarNoticias();  // Atualiza a lista de notícias
        } catch (SQLException e) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro", "Erro ao excluir notícia." + e.getMessage()));
        }
    }

    // Salvar nova notícia
    public String salvarNovaNoticia() {
        if (novaNoticia.getTitulo() == null || novaNoticia.getTitulo().isEmpty()) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro", "O título é obrigatório."));
            return null;
        }

        String caminhoImagem = salvarImagem();

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO noticias (titulo, subtitulo, conteudo, imagem, data_publicacao) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, novaNoticia.getTitulo());
            stmt.setString(2, novaNoticia.getSubtitulo());
            stmt.setString(3, novaNoticia.getConteudo());
            stmt.setString(4, caminhoImagem);
            stmt.setTimestamp(5, new Timestamp(System.currentTimeMillis()));
            stmt.executeUpdate();
        } catch (SQLException e) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro", "Erro ao salvar notícia." + e.getMessage()));
        }

        carregarNoticias();
        novaNoticia = new Noticia();
        imagemArquivo = null;

        return "listarNoticias?faces-redirect=true";
    }

    // Salvar imagem no servidor
    private String salvarImagem() {
        String caminhoImagem = null;
        if (imagemArquivo != null && imagemArquivo.getSize() > 0) {
            try {
                String pastaImagens = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/img");
                File pasta = new File(pastaImagens);
                if (!pasta.exists()) pasta.mkdirs();

                String nomeArquivo = System.currentTimeMillis() + "_" + imagemArquivo.getSubmittedFileName();
                caminhoImagem = "img/" + nomeArquivo;
                File arquivoDestino = new File(pasta, nomeArquivo);

                try (InputStream input = imagemArquivo.getInputStream();
                     FileOutputStream output = new FileOutputStream(arquivoDestino)) {
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = input.read(buffer)) != -1) {
                        output.write(buffer, 0, bytesRead);
                    }
                }
            } catch (Exception e) {
                FacesContext.getCurrentInstance().addMessage(null,
                        new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro", "Erro ao salvar imagem." + e.getMessage()));
            }
        }
        return caminhoImagem;
    }

    // Adicionar um comentário
    public void adicionarComentario() {
        if (novoComentario == null || novoComentario.isEmpty()) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro", "O comentário não pode estar vazio."));
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO comentarios (noticia_id, comentario, data_comentario) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, noticiaSelecionada.getId());
            stmt.setString(2, novoComentario);
            stmt.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
            stmt.executeUpdate();

            novoComentario = "";  // Limpar campo de comentário
            carregarNoticia();    // Atualizar os comentários
        } catch (SQLException e) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro", "Erro ao adicionar comentário." + e.getMessage()));
        }
    }
}