package com.goodnews.services;

import com.goodnews.models.Comentario;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.util.List;

@Stateless
public class ComentarioService {

    @PersistenceContext
    private EntityManager em;

    // Contar o número de comentários para uma notícia específica
    public int contarComentariosPorNoticia(Long noticiaId) {
        String query = "SELECT COUNT(c) FROM Comentario c WHERE c.noticiaId = :noticiaId";
        TypedQuery<Long> typedQuery = em.createQuery(query, Long.class);
        typedQuery.setParameter("noticiaId", noticiaId);
        return typedQuery.getSingleResult().intValue();
    }

    // Método para listar todos os comentários (exemplo adicional)
    public List<Comentario> listarComentariosPorNoticia(Long noticiaId) {
        String query = "SELECT c FROM Comentario c WHERE c.noticiaId = :noticiaId";
        TypedQuery<Comentario> typedQuery = em.createQuery(query, Comentario.class);
        typedQuery.setParameter("noticiaId", noticiaId);
        return typedQuery.getResultList();
    }

    // Método para adicionar um novo comentário
    public void adicionarComentario(Comentario comentario) {
        em.persist(comentario);
    }

    // Método para excluir um comentário
    public void excluirComentario(Long comentarioId) {
        Comentario comentario = em.find(Comentario.class, comentarioId);
        if (comentario != null) {
            em.remove(comentario);
        }
    }
}
