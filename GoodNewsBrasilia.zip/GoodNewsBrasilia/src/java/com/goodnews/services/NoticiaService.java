package com.goodnews.services;

import com.goodnews.models.Noticia;
import com.goodnews.utils.DBConnection;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.Part;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@ManagedBean
@ViewScoped
public class NoticiaService {

    private Noticia noticia;
    private Part imagemArquivo;
    private String caminhoImagemExistente;

    // Método chamado ao carregar a página
    @PostConstruct
    public void init() {
        String idParam = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("id");
        if (idParam != null) {
            int id = Integer.parseInt(idParam);
            noticia = buscarNoticiaPorId(id);
            caminhoImagemExistente = noticia.getImagem(); // Armazena o caminho da imagem existente
        } else {
            noticia = new Noticia(); // Inicializar com uma nova instância
        }
    }

    public Noticia buscarNoticiaPorId(int id) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM noticias WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Noticia noticia = new Noticia();
                noticia.setId(rs.getInt("id"));
                noticia.setTitulo(rs.getString("titulo"));
                noticia.setSubtitulo(rs.getString("subtitulo"));
                noticia.setConteudo(rs.getString("conteudo"));
                noticia.setImagem(rs.getString("imagem"));
                return noticia;
            }
        } catch (SQLException e) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro", "Erro ao carregar notícia: " + e.getMessage()));
        }
        return null;
    }

    public boolean atualizarNoticia() {
        if (noticia.getTitulo() == null || noticia.getTitulo().isEmpty()) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro", "O título é obrigatório."));
            return false;
        }

        // Salvar a imagem, se uma nova imagem for fornecida
        if (imagemArquivo != null && imagemArquivo.getSize() > 0) {
            String novoCaminhoImagem = salvarImagem(imagemArquivo);
            if (novoCaminhoImagem != null) {
                noticia.setImagem(novoCaminhoImagem);
            }
        } else {
            // Se nenhuma nova imagem for carregada, manter a imagem existente
            noticia.setImagem(caminhoImagemExistente);
        }

        // Atualizar a notícia no banco de dados
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "UPDATE noticias SET titulo = ?, subtitulo = ?, conteudo = ?, imagem = ? WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, noticia.getTitulo());
            stmt.setString(2, noticia.getSubtitulo());
            stmt.setString(3, noticia.getConteudo());
            stmt.setString(4, noticia.getImagem());
            stmt.setInt(5, noticia.getId());
            stmt.executeUpdate();

            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_INFO, "Sucesso", "Notícia atualizada com sucesso."));
            return true;
        } catch (SQLException e) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro", "Erro ao atualizar notícia: " + e.getMessage()));
            return false;
        }
    }

    // Método para salvar a imagem
    private String salvarImagem(Part imagemArquivo) {
        String diretorio = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/") + "img/";
        File dir = new File(diretorio);

        // Criar o diretório se ele não existir
        if (!dir.exists()) {
            dir.mkdirs();
        }

        String caminhoImagem = diretorio + imagemArquivo.getSubmittedFileName();
        try (InputStream inputStream = imagemArquivo.getInputStream();
             FileOutputStream outputStream = new FileOutputStream(new File(caminhoImagem))) {

            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            return "img/" + imagemArquivo.getSubmittedFileName(); // Retorna o caminho relativo
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro", "Erro ao salvar a imagem: " + e.getMessage()));
            return null;
        }
    }

    // Getters e Setters
    public Noticia getNoticia() {
        return noticia;
    }

    public Part getImagemArquivo() {
        return imagemArquivo;
    }

    public void setImagemArquivo(Part imagemArquivo) {
        this.imagemArquivo = imagemArquivo;
    }
}
