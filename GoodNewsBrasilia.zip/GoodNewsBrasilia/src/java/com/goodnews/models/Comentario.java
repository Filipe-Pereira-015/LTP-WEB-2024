package com.goodnews.models;

import java.io.Serializable;

public class Comentario implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;
    private int noticiaId;  
    private String comentario;
    private String dataComentario;

    public Comentario() {
    }

    public Comentario(Long id, int noticiaId, String comentario, String dataComentario) {
        this.id = id;
        this.noticiaId = noticiaId;
        this.comentario = comentario;
        this.dataComentario = dataComentario;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getNoticiaId() {
        return noticiaId;
    }

    public void setNoticiaId(int noticiaId) {
        this.noticiaId = noticiaId;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public String getDataComentario() {
        return dataComentario;
    }

    public void setDataComentario(String dataComentario) {
        this.dataComentario = dataComentario;
    }

    @Override
    public String toString() {
        return "Comentario{" +
                "id=" + id +
                ", noticiaId=" + noticiaId +
                ", comentario='" + comentario + '\'' +
                ", dataComentario='" + dataComentario + '\'' +
                '}';
    }

    public void setNoticia(Noticia noticia) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}