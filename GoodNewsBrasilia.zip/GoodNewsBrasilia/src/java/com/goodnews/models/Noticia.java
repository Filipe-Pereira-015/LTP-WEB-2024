package com.goodnews.models;

import java.util.Date;
import java.util.List;

public class Noticia {
    private int id;
    private String titulo;
    private String subtitulo; 
    private String conteudo;
    private String imagem; 
    private Date dataPublicacao; 
    private List<Comentario> comentarios; 

    public Noticia() {
        this.dataPublicacao = new Date(); 
    }

    public Noticia(int id, String titulo, String subtitulo, String conteudo, String imagem, Date dataPublicacao, List<Comentario> comentarios) {
        this.id = id;
        this.titulo = titulo;
        this.subtitulo = subtitulo;
        this.conteudo = conteudo;
        this.imagem = imagem;
        this.dataPublicacao = dataPublicacao != null ? dataPublicacao : new Date(); 
        this.comentarios = comentarios;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getSubtitulo() {
        return subtitulo;
    }

    public void setSubtitulo(String subtitulo) {
        this.subtitulo = subtitulo;
    }

    public String getConteudo() {
        return conteudo;
    }

    public void setConteudo(String conteudo) {
        this.conteudo = conteudo;
    }

    public String getImagem() {
        return imagem;
    }

    public void setImagem(String imagem) {
        this.imagem = imagem;
    }

    public Date getDataPublicacao() {
        return dataPublicacao;
    }

    public void setDataPublicacao(Date dataPublicacao) {
        this.dataPublicacao = dataPublicacao;
    }

    public List<Comentario> getComentarios() {
        return comentarios;
    }

    public void setComentarios(List<Comentario> comentarios) {
        this.comentarios = comentarios;
    }

    @Override
    public String toString() {
        return "Noticia{" +
                "id=" + id +
                ", titulo='" + titulo + '\'' +
                ", subtitulo='" + subtitulo + '\'' +
                ", conteudo='" + conteudo + '\'' +
                ", imagem='" + imagem + '\'' +
                ", dataPublicacao=" + dataPublicacao +
                ", comentarios=" + comentarios +
                '}';
    }
}