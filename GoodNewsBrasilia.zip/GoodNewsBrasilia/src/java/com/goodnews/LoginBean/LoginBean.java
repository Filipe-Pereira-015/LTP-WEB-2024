package com.goodnews.LoginBean;

import com.goodnews.utils.UserAuthentication;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.application.FacesMessage;

@ManagedBean(name = "loginBean")
@SessionScoped
public class LoginBean {

    private String email;
    private String senha;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String login() {
        boolean isValidUser = UserAuthentication.validateLogin(email, senha);

        if (isValidUser) {
            
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Login bem-sucedido"));
            return "listarNoticias?faces-redirect=true"; 
        } else {
            
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Credenciais inválidas", null));
            return null; 
        }
    }
}