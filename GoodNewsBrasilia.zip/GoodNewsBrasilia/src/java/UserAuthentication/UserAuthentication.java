package com.goodnews.utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserAuthentication {

    public static boolean registerUser(String nome, String email, String senha, String cpf) {
        Connection conn = null;
        PreparedStatement stmt = null;
        String sql = "INSERT INTO login (nome, email, senha, cpf) VALUES (?, ?, ?, ?)";
        
        try {
     
            conn = DBConnection.getConnection();
            
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, nome);  
            stmt.setString(2, email);  
            stmt.setString(3, senha);  
            stmt.setString(4, cpf);    
            
            int rowsInserted = stmt.executeUpdate();
          
            return rowsInserted > 0;
        } catch (SQLException e) {
            
            e.printStackTrace();
            return false;
        } finally {
            
            DBConnection.closeConnection(conn);
        }
    }
    
    public static boolean validateLogin(String email, String senha) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;  
        String sql = "SELECT * FROM login WHERE email = ? AND senha = ?";
        
        try {
            
            conn = DBConnection.getConnection();
            
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, email);  
            stmt.setString(2, senha);  
            
            rs = stmt.executeQuery();
            
            return rs.next();
        } catch (SQLException e) {
           
            e.printStackTrace();
            return false;
        } finally {
           
            DBConnection.closeConnection(conn);
        }
    }
}